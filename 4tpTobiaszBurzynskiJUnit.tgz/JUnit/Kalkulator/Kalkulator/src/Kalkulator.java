import java.util.ArrayList;
import java.util.List;

public class Kalkulator {
    private double wynik;
    private List<String> lista = new ArrayList<>();

    public double dod(double a, double b) {
        wynik = a + b;
        dodajDoListy(a + " + " + b + " = " + wynik);
        return wynik;
    }

    public double odej(double a, double b) {
        wynik = a - b;
        dodajDoListy(a + " - " + b + " = " + wynik);
        return wynik;
    }

    public double pom(double a, double b) {
        wynik = a * b;
        dodajDoListy(a + " * " + b + " = " + wynik);
        return wynik;
    }

    public double podz(double a, double b) {
        if(b == 0) throw new ArithmeticException("Dzielenie przez zero");
        wynik = a / b;
        dodajDoListy(a + " / " + b + " = " + wynik);
        return wynik;
    }

    private void dodajDoListy(String operacja) {
        lista.add(operacja);
    }

    public String pokazLista() {
        return String.join("\n",  lista);
    }
}