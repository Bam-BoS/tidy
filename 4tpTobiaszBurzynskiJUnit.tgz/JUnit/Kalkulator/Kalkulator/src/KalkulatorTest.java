import org.junit.Test;
import static org.junit.Assert.*;

public class KalkulatorTest {

    @Test
    public void testDodaj() {
        Kalkulator kalkulator = new Kalkulator();
        assertEquals(2.0, kalkulator.dod(1, 1), 0.001);
    }

    @Test
    public void testOdejmij() {
        Kalkulator kalkulator = new Kalkulator();
        assertEquals(0.0, kalkulator.odej(1, 1), 0.001);
    }

    @Test
    public void testPomnoz() {
        Kalkulator kalkulator = new Kalkulator();
        assertEquals(2.0, kalkulator.pom(2, 1), 0.001);
    }

    @Test
    public void testPodziel() {
        Kalkulator kalkulator = new Kalkulator();
        assertEquals(0.5, kalkulator.podz(1, 2), 0.001);
    }

    @Test(expected = ArithmeticException.class)
    public void testDzieleniePrzezZero() {
        Kalkulator kalkulator = new Kalkulator();
        kalkulator.podz(0, 0);
    }

    @Test
    public void testPokazListe() {
        Kalkulator kalkulator = new Kalkulator();
        kalkulator.dod(1, 1);
        kalkulator.odej(1, 1);
        String lista = kalkulator.pokazLista();
        assertTrue(lista.contains("1.0 + 1.0 = 2.0"));
        assertTrue(lista.contains("1.0 - 1.0 = 0.0"));
    }
}