import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;

public class BankPrzelewTest {

    @Test
    public void testTworzeniePrzelewu() {
        BankPrzelew przelew = new BankPrzelew("Jan", "Kowalski", 2.37,
                "1", "2");
        assertNotNull(przelew);
        assertEquals("Jan", przelew.getImie());
        assertEquals("Kowalski", przelew.getNazwisko());
        assertEquals(2.37, przelew.getKwota(), 0.001);
    }

    @Test
    public void testWykonajPrzelew() {
        BankPrzelew przelew = new BankPrzelew("Jan", "Kowalski", 2.37,
                "1", "2");
        assertTrue(przelew.wykonajPrzelew());
    }

    @Test
    public void testFormatowanieNumeruKonta() {
        BankPrzelew przelew = new BankPrzelew("Jan", "Kowalski", 2.37,
                "1", "2");
        String numer = przelew.getNumerKontaZrodlowego();
        assertTrue(numer.contains("1"));
    }
    @Test
    public void testToString() {
        BankPrzelew przelew = new BankPrzelew("Jan", "Kowalski", 2.37,
                "1", "2");
        String wynik = przelew.toString();
        assertTrue(wynik.contains("Jan Kowalski"));
        assertTrue(wynik.contains("2.37"));
    }
}