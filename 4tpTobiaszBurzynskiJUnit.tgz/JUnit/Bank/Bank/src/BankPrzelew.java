import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class BankPrzelew implements Serializable {
    private String imie;
    private String nazwisko;
    private double kwota;
    private String numerKontaZ;
    private String numerKontaDo;
    private LocalDateTime dataCzas;

    public BankPrzelew(String imie, String nazwisko, double kwota,
                       String numerZrodlowy, String numerDocelowy) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.kwota = kwota;
        this.numerKontaZ = formatujNumerKonta(numerZrodlowy);
        this.numerKontaDo = formatujNumerKonta(numerDocelowy);
        this.dataCzas = LocalDateTime.now();
    }

    private String formatujNumerKonta(String numer) {
        return numer.replaceAll("(.{4})", "$1_").replaceAll("_$", "");
    }

    public boolean wykonajPrzelew() {
        try {
            zapiszDoPliku();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public void zapiszDoPliku() throws IOException {
        String nazwaPliku = nazwisko + "_" +
                dataCzas.format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".ser";
        try (ObjectOutputStream wyjscie = new ObjectOutputStream(
                new FileOutputStream(nazwaPliku))) {
            wyjscie.writeObject(this);
        }
    }

    public static String wyswietlPlik(String nazwaPliku) throws IOException, ClassNotFoundException {
        try (ObjectInputStream wejscie = new ObjectInputStream(
                new FileInputStream(nazwaPliku))) {
            BankPrzelew przelew = (BankPrzelew) wejscie.readObject();
            return przelew.toString();
        }
    }

    @Override
    public String toString() {
        return String.format("Imię: %s %s\nKwota: %.2f\nZ konta: %s\nNa konto: %s\nData: %s",
                imie, nazwisko, kwota, numerKontaZ,
                numerKontaDo, dataCzas);
    }

    // Gettery
    public String getImie() { return imie; }
    public String getNazwisko() { return nazwisko; }
    public double getKwota() { return kwota; }
    public String getNumerKontaZrodlowego() { return numerKontaZ; }
    public String getNumerKontaDocelowego() { return numerKontaDo; }
    public LocalDateTime getDataCzas() { return dataCzas; }
}