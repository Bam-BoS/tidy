import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class EDocumentTest {
    private EDocumentModel model;

    @BeforeEach
    void setUp() {
        model = new EDocumentModel();
    }

    @Test
    void testInitialAuthorsEmpty() {
        assertTrue(model.getAuthors().isEmpty());
    }

    @Test
    void testSetUserData() {
        model.setUserData("2A", "Nowak", "Anna");
        assertEquals(1, model.getAuthors().size());
        EDocumentModel.Author author = model.getAuthors().get(0);
        assertEquals("2A", author.getUnit());
        assertEquals("Nowak", author.getNazw());
        assertEquals("Anna", author.getImie());
    }

    @Test
    void testSetUserDataOverwritesPrevious() {
        model.setUserData("1B", "Kowalski", "Jan");
        model.setUserData("3C", "Wiśniewski", "Piotr");
        assertEquals(1, model.getAuthors().size());
        assertEquals("3C", model.getAuthors().get(0).getUnit());
    }

    @Test
    void testExportJsonContainsMeta() {
        String json = model.exportToJson();
        assertTrue(json.contains("\"meta\""));
        assertTrue(json.contains("\"edocVer\": \"1.0\""));
        assertTrue(json.contains("\"docname\": \"piabd-sql-spr1\""));
        assertTrue(json.contains("\"doctype\": \"workshop\""));
        assertTrue(json.contains("\"docver\": \"1.0.1\""));
    }

    @Test
    void testExportJsonWithEmptyAuthors() {
        String json = model.exportToJson();
        assertTrue(json.contains("\"authors\": ["));
        assertTrue(json.contains("]"));
        assertFalse(json.contains("unit"));
    }

    @Test
    void testExportJsonWithOneAuthor() {
        model.setUserData("5D", "Zieliński", "Tomasz");
        String json = model.exportToJson();
        assertTrue(json.contains("\"unit\": \"5D\""));
        assertTrue(json.contains("\"nazw\": \"Zieliński\""));
        assertTrue(json.contains("\"imie\": \"Tomasz\""));
    }

    @Test
    void testEscapeJsonQuotes() {
        EDocumentModel m = new EDocumentModel();
        m.setUserData("A\"B", "O'Neil", "Jan\\Nowak");
        String json = m.exportToJson();
        assertTrue(json.contains("\\\""));
        assertTrue(json.contains("\\\\"));
    }

    @Test
    void testExportJsonFormatValid() {
        model.setUserData("X", "Y", "Z");
        String json = model.exportToJson();
        assertTrue(json.startsWith("{") && json.endsWith("}\n"));
        long openBraces = json.chars().filter(ch -> ch == '{').count();
        long closeBraces = json.chars().filter(ch -> ch == '}').count();
        assertEquals(openBraces, closeBraces);
    }
}