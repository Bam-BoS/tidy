import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class EDocumentGUI extends JFrame {
    private final EDocumentModel model;
    private JTextField klasaField;
    private JTextField nazwiskoField;
    private JTextField imieField;
    private JButton zatwierdzButton;
    private JButton pobierzButton;
    private JLabel statusLabel;

    public EDocumentGUI() {
        model = new EDocumentModel();
        initializeUI();
    }

    private void initializeUI() {
        setTitle("eDocument");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        setSize(480, 300);
        setLocationRelativeTo(null);

        JPanel userPanel = createUserPanel();
        add(userPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        statusLabel = new JLabel(" ");
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        bottomPanel.add(statusLabel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        pobierzButton = new JButton("Pobierz JSON");
        pobierzButton.setEnabled(false);
        pobierzButton.addActionListener(this::onPobierz);
        buttonPanel.add(pobierzButton);
        bottomPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(bottomPanel, BorderLayout.SOUTH);
        setVisible(true);
    }

    private JPanel createUserPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(new TitledBorder("Dane - zapisz przed pobraniem"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Klasa:"), gbc);
        gbc.gridx = 1;
        klasaField = new JTextField(15);
        panel.add(klasaField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Nazwisko:"), gbc);
        gbc.gridx = 1;
        nazwiskoField = new JTextField(15);
        panel.add(nazwiskoField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Imię:"), gbc);
        gbc.gridx = 1;
        imieField = new JTextField(15);
        panel.add(imieField, gbc);

        gbc.gridx = 1; gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.EAST;
        zatwierdzButton = new JButton("Zatwierdź");
        zatwierdzButton.addActionListener(this::onZatwierdz);
        panel.add(zatwierdzButton, gbc);

        return panel;
    }

    private void onZatwierdz(ActionEvent e) {
        String klasa = klasaField.getText().trim();
        String nazwisko = nazwiskoField.getText().trim();
        String imie = imieField.getText().trim();

        if (klasa.isEmpty() || nazwisko.isEmpty() || imie.isEmpty()) {
            statusLabel.setText("Wypełnij wszystkie pola!");
            statusLabel.setForeground(Color.RED);
            return;
        }

        model.setUserData(klasa, nazwisko, imie);
        pobierzButton.setEnabled(true);
        statusLabel.setText(String.format("Zatwierdzono: %s %s, klasa %s", imie, nazwisko, klasa));
        statusLabel.setForeground(new Color(0, 100, 0));
    }

    private void onPobierz(ActionEvent e) {
        if (model.getAuthors().isEmpty()) {
            statusLabel.setText("Najpierw zatwierdź dane ucznia.");
            statusLabel.setForeground(Color.RED);
            return;
        }

        String json = model.exportToJson();
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setSelectedFile(new java.io.File("Dokument.json"));
        int option = fileChooser.showSaveDialog(this);
        if (option == JFileChooser.APPROVE_OPTION) {
            java.io.File file = fileChooser.getSelectedFile();
            try (FileWriter fw = new FileWriter(file)) {
                fw.write(json);
                fw.flush();
                statusLabel.setText("Plik JSON zapisany: " + file.getAbsolutePath());
                statusLabel.setForeground(Color.BLUE);
            } catch (IOException ex) {
                statusLabel.setText("Błąd zapisu: " + ex.getMessage());
                statusLabel.setForeground(Color.RED);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(EDocumentGUI::new);
    }
}

class EDocumentModel {
    private final Meta meta;
    private final List<Author> authors;

    public EDocumentModel() {
        this.meta = new Meta();
        this.authors = new ArrayList<>();
    }

    public void setUserData(String unit, String nazw, String imie) {
        authors.clear();
        authors.add(new Author(unit, nazw, imie));
    }

    public List<Author> getAuthors() {
        return authors;
    }

    public String exportToJson() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"meta\": {\n");
        sb.append("    \"edocVer\": \"").append(escapeJson(meta.edocVer)).append("\",\n");
        sb.append("    \"docname\": \"").append(escapeJson(meta.docname)).append("\",\n");
        sb.append("    \"doctype\": \"").append(escapeJson(meta.doctype)).append("\",\n");
        sb.append("    \"docver\": \"").append(escapeJson(meta.docver)).append("\"\n");
        sb.append("  },\n");
        sb.append("  \"authors\": [\n");
        for (int i = 0; i < authors.size(); i++) {
            Author a = authors.get(i);
            sb.append("    {\n");
            sb.append("      \"unit\": \"").append(escapeJson(a.getUnit())).append("\",\n");
            sb.append("      \"nazw\": \"").append(escapeJson(a.getNazw())).append("\",\n");
            sb.append("      \"imie\": \"").append(escapeJson(a.getImie())).append("\"\n");
            sb.append("    }");
            if (i < authors.size() - 1) sb.append(",");
            sb.append("\n");
        }
        sb.append("  ]\n");
        sb.append("}\n");
        return sb.toString();
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    private static class Meta {
        final String edocVer = "1.0";
        final String docname = "piabd-sql-spr1";
        final String doctype = "workshop";
        final String docver = "1.0.1";
    }

    public static class Author {
        private final String unit;
        private final String nazw;
        private final String imie;

        public Author(String unit, String nazw, String imie) {
            this.unit = unit;
            this.nazw = nazw;
            this.imie = imie;
        }

        public String getUnit() { return unit; }
        public String getNazw() { return nazw; }
        public String getImie() { return imie; }
    }
}