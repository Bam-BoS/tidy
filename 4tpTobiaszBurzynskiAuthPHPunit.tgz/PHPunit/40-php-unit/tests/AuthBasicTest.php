<?php
require('app/AuthBasic.php');

use PHPUnit\Framework\TestCase;

class AuthBasicTest extends TestCase {
    private $instance;

    public function setUp() : void {
        $this->instance = new AuthBasic();
    }

    public function tearDown() : void {
        unset($this->instance);
    }

    public function testCreateCode(){
        $out = $this->instance->createCode();
        $len = strlen($out);
        $this->assertIsNumeric($out, 'Wylosowano: '.$out);
        $this->assertEquals(6, $len, 'Długość: '.$len);

        $out = $this->instance->createCode(4);
        $len = strlen($out);
        $this->assertIsNumeric($out, 'Wylosowano: '.$out);
        $this->assertEquals(4, $len, 'Długość: '.$len);

        $out = str_pad(1111, 6, '0', STR_PAD_LEFT);
        $len = strlen($out);
        $this->assertIsNumeric($out, 'Wylosowano: '.$out);
        $this->assertEquals(6, $len, 'Długość: '.$len);
    }

    public function testCreateAuthToken(){
        $exp = array(
            'emlAuth' => 'gpetri@gplweb.pl',
            'authCode' => '131313',
            'authDate' => date("Y-m-d"),
            'authHour' => date("H:i:s"),
            'addrIp' => '127.0.0.1',
            'reqOs' => 'Linux',
            'reqBrw' => 'FF'
        );

        $out = $this->instance->createAuthToken('gpetri@gplweb.pl', 13);
        $out['authCode'] = '131313';
        $out['addrIp'] = '127.0.0.1';
        $out['reqOs'] = 'Linux';
        
        $this->assertEquals($exp, $out, 'Tablice są różne');
    }

    public function testGenFingerprint(){
        $out = $this->instance->genFingerprint('sha256');
        $this->assertIsString($out);
        $this->assertEquals(64, strlen($out));
    }

    public function testVerifyQuickRegCode(){
        $this->assertTrue($this->instance->verifyQuickRegCode('123456'));
        $this->assertFalse($this->instance->verifyQuickRegCode('12345'));
        $this->assertFalse($this->instance->verifyQuickRegCode('abc123'));
    }
}