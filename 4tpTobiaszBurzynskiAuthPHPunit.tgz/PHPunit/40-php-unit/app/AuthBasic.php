<?php
/**
 * Klasa do autoryzacji jednorazowego dostępu do fragmentu serwisu
 * @author Grzegorz Petri
 * @since 0.2
 */
class AuthBasic {

    /**
     * @desc Generuje odcisk palca na podstawie algorytmu
     * @param string $algo Algorytm hashowania
     * @return string Wygenerowany odcisk
     */
    public function genFingerprint($algo){
        return hash($algo, uniqid());
    }

    /**
     * @desc Generuje kod wymagany do podania podczas autoryzacji dostępu, wg. podanych parametrów
     * @param int $length Długość kodu - liczba znaków; domyślna wartość 6
     * @param int $min Minimalna wartość dla generowanego numeru; domyślna wartość 1
     * @param int $max Maksymalna wartość dla generowanego numeru; domyślna wartość 999999
     * @return string Zwraca wygenerowaną na podstawie parametrów liczbę, uzupełnioną zerami
     */
    public function createCode($length = 6, $min = 1, $max = 999999){
    $max = min($max, pow(10, $length) - 1);
    $code = rand($min, $max);
    return str_pad($code, $length, '0', STR_PAD_LEFT);
}

    /**
     * @desc Tworzy wpis w BD z numerem pozwalającym na uwierzytelnienie Requesta
     * Tworzony Token do uwierzytelnienia zapisując adres Email oraz ID użytkownika
     * Token musi zostać wysłany na pocztę użytkownika, stąd zwracany jest Obiekt informacyjny
     * @param string $email Adres email użytkownika do uwierzytelnienia
     * @param int $id Numer ID użytkownika do uwierzytelnienia
     * @return array|false Wygenerowany Token LUB Fałsz
     */
    public function createAuthToken($email, $id){
        $authCode = $this->createCode();
        $authDate = date("Y-m-d");
        $authHours = date("H:i:s");
        $addrIp = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $opSys = $_SERVER['HTTP_USER_AGENT'] ?? 'Linux';
        $browser = 'FF';

        $cont = array(
            'emlAuth' => $email,
            'authCode' => $authCode,
            'authDate' => $authDate,
            'authHour' => $authHours,
            'addrIp' => $addrIp,
            'reqOs' => $opSys,
            'reqBrw' => $browser
        );

        $file = dirname(__FILE__).'/db.txt';
        file_put_contents($file, serialize($cont));
        
        return $cont;
    }

    public function compAuthCode($emlAuth, $idzAuth, $authCode){}
    public function doAuthByEmail($person, $email){}
    public function checkIfValidReqest($person, $email){}
    private function checkIfValidReqest2f($emlAuth, $idzAuth){}
    
    /**
     * @desc Weryfikuje kod szybkiej rejestracji
     * @param string $codeNo Kod do weryfikacji
     * @return bool Wynik weryfikacji
     */
    public function verifyQuickRegCode($codeNo){
        return is_numeric($codeNo) && strlen($codeNo) === 6;
    }
}